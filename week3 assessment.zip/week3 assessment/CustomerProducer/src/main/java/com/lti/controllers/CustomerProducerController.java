package com.lti.controllers;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.Exception.ResourceNotFoundException;
import com.lti.model.Customer;
import com.lti.repository.CustomerRepository;


@CrossOrigin(origins="*")
@RestController
@RequestMapping("/bank")
public class CustomerProducerController {

	 private static final Logger logger = LoggerFactory.getLogger(CustomerProducerController.class);
		
	@Autowired
	CustomerRepository custrep;
	
	 @PostMapping("/customer")
	 public Customer addCustomer(@RequestBody Customer customer) {
	        return   custrep.save(customer);
	      
	    }

	 

	 @GetMapping("/getCustomer")
		 public List<Customer> getAllCustomersDetails(){
			
			
			 return  custrep.findAll();
		 }
	 

	 @SuppressWarnings("customerProducerServiceFallback")
	public String customerProducerServiceFallback() {
			
		 return "Customer producer service is down at this time !!";
			
		}
	 
	 @DeleteMapping("/deleteCustomer/{id}")
	 public String deleteCustomer(@PathVariable(value = "id") int custid) throws ResourceNotFoundException {
		 Customer cust=custrep.findById(custid)
					.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + custid));
			
		 custrep.delete(cust);
		 return "deleted  " + custid;
	 }
	 
	 @PutMapping("/updateCustomer/{id}")
		public ResponseEntity<Customer> updateCustomer(@PathVariable(value = "id") int custid,
				 @RequestBody Customer custDetails) throws ResourceNotFoundException  {
		
			logger.info("****************Controller Class :update customers****************");
			Customer cust = custrep.findById(custid)
					.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + custid));
			cust.setName(custDetails.getName());
			cust.setAddress(custDetails.getAddress());
			cust.setAge(custDetails.getAge());
			cust.setTypeofAccount(custDetails.getTypeofAccount());
			final Customer updatedCustomer = custrep.save(cust);

			return ResponseEntity.ok(updatedCustomer);
		}
}
